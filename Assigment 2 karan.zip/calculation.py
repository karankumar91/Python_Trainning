# crete a calculator program using modular approach

import Module

a=int(input("enter 1 value:"))
b=int(input("enter 2 value:"))
Module.add(a,b)
Module.sub(a,b)
Module.mul(a,b)
Module.div(a,b)