# Write A Program to check odd and even number #

num=int(input("Enter the Number:"))
if (num%2==0):
    print("its a even number:")
else:
    print("its a odd number")