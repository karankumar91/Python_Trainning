def add(x,y):
    z=x+y
    print(z)

def sub(x,y):
    z=x-y
    print(z)

def mul(x,y):
    z=x*y
    print(z)

def div(x,y):
    z=x/y
    print(z)