#crete a complex dictionary and traverse 

d={"key1":"my","key2":"name",3:"is",4:"karan","list":[1,2,3,4],"tuple":(10,11,12),"set":{1,3,5,7}}
for i,j in d.items():
    print(d)
    break